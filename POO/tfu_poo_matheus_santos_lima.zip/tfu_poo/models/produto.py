
from exceptions.erros import PrecoInvalidoError


class Produto:
    def __init__(self, id: int, nome: str, preco: float, estoque: int, descricao: str):
        self.id = id
        self.nome = nome
        self._preco = preco
        self.estoque = estoque
        self.descricao = descricao

    def atualizar_estoque(self, nova_quantidade: int):
        """Atualiza a quantidade do produto no estoque"""
        self.estoque = nova_quantidade

    @property
    def preco(self):
        return self._preco
    
    @preco.setter
    def preco(self, valor):
        if valor < 0:
            raise PrecoInvalidoError("Preço não pode ser negativo")
        self._preco = valor
        


    def __str__(self):
        """Mostrar informações do produto"""
        return f"produto: {self.nome} - Valor: R$ {self._preco} - Quantidade em estoque: {self.estoque} - Descrição do produto: {self.descricao}"